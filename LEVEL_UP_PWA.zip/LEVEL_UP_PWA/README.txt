LEVEL UP — primera versión PWA
================================

Incluye:
- Tareas con casillas y guardado local.
- Lista de deseos para Xbox y Nintendo Switch (sin precios en tiempo real todavía).
- Rutina casera inicial y contador de entrenamientos.
- Temporizador de concentración de 25 minutos.
- Diseño adaptable para móvil y modo instalable PWA.

IMPORTANTE:
Para instalarla como aplicación desde Chrome, estos archivos deben publicarse en un sitio HTTPS.
Abrir index.html localmente sirve para una prueba básica, pero la instalación PWA y el modo sin conexión necesitan servirse correctamente.
Los datos se guardan en el almacenamiento local del navegador del dispositivo. No se sincronizan entre dispositivos.
El temporizador no bloquea otras aplicaciones y puede no continuar si Android suspende el navegador.

Siguiente paso sugerido:
Publicar estos archivos en un repositorio propio y habilitar alojamiento estático HTTPS (por ejemplo, GitHub Pages). No subas contraseñas ni claves privadas.
