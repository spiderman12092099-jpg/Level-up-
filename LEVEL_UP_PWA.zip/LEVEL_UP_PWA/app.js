const $ = id => document.getElementById(id);
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
const save = (key, value) => localStorage.setItem(key, JSON.stringify(value));
let tasks = read('lu_tasks', []);
let games = read('lu_games', []);
let workoutCount = read('lu_workouts', 0);
let sessions = read('lu_sessions', 0);
let minutes = read('lu_minutes', 0);
let remaining = 25 * 60, timerId = null, running = false;

$('today').textContent = new Intl.DateTimeFormat('es-MX',{weekday:'short',day:'numeric',month:'short'}).format(new Date()).toUpperCase();
function showTab(name) {
  document.querySelectorAll('.panel').forEach(p => p.classList.toggle('hidden', p.id !== name));
  document.querySelectorAll('.tab').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
}
document.querySelectorAll('.tab').forEach(b => b.addEventListener('click', () => showTab(b.dataset.tab)));
document.querySelectorAll('[data-go]').forEach(b => b.addEventListener('click', () => showTab(b.dataset.go)));

function renderTasks() {
  const root = $('taskList'); root.innerHTML = '';
  if (!tasks.length) root.innerHTML = '<div class="empty">Todavía no hay tareas. Añade una para empezar.</div>';
  tasks.forEach((t,i) => {
    const row = document.createElement('div'); row.className = 'task' + (t.done ? ' done' : '');
    const check = document.createElement('input'); check.type='checkbox'; check.checked=t.done; check.setAttribute('aria-label','Marcar tarea');
    check.addEventListener('change', () => { tasks[i].done=check.checked; save('lu_tasks',tasks); renderTasks(); });
    const name = document.createElement('span'); name.className='task-name'; name.textContent=t.name;
    const del = document.createElement('button'); del.className='delete'; del.textContent='×'; del.setAttribute('aria-label','Eliminar tarea');
    del.addEventListener('click', () => { tasks.splice(i,1); save('lu_tasks',tasks); renderTasks(); });
    row.append(check,name,del); root.append(row);
  });
  const done = tasks.filter(t=>t.done).length;
  $('progressText').textContent = `${done} de ${tasks.length} tareas completadas`;
  $('progressFill').style.width = tasks.length ? `${done/tasks.length*100}%` : '0%';
}
$('taskForm').addEventListener('submit', e => { e.preventDefault(); const name=$('taskInput').value.trim(); if(!name)return; tasks.push({name,done:false}); save('lu_tasks',tasks); $('taskInput').value=''; renderTasks(); });

function renderGames() {
  const root=$('gameList'); root.innerHTML='';
  if(!games.length) root.innerHTML='<div class="empty">Tu lista de deseos está vacía.</div>';
  games.forEach((g,i)=>{
    const row=document.createElement('div'); row.className='task';
    const name=document.createElement('span'); name.className='task-name'; name.textContent=`${g.name} · ${g.platform}${g.price ? ' · objetivo $'+g.price+' MXN':''}`;
    const del=document.createElement('button'); del.className='delete'; del.textContent='×'; del.setAttribute('aria-label','Eliminar juego'); del.onclick=()=>{games.splice(i,1);save('lu_games',games);renderGames();};
    row.append(name,del);root.append(row);
  });
}
$('gameForm').addEventListener('submit',e=>{e.preventDefault();games.push({name:$('gameName').value.trim(),platform:$('gamePlatform').value,price:$('gamePrice').value});save('lu_games',games);$('gameForm').reset();renderGames();});

function renderWorkout(){ $('workoutStats').textContent=`Entrenamientos completados: ${workoutCount}`; }
$('workoutDone').addEventListener('click',()=>{workoutCount++;save('lu_workouts',workoutCount);renderWorkout();$('workoutDone').textContent='¡Entrenamiento registrado!';setTimeout(()=>$('workoutDone').textContent='Marcar entrenamiento completado',1600);});

function renderTimer(){const m=Math.floor(remaining/60),s=remaining%60;$('timerDisplay').textContent=`${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;$('focusSessions').textContent=sessions;$('focusMinutes').textContent=minutes;}
function stopTimer(){if(timerId){clearInterval(timerId);timerId=null;}running=false;}
$('startTimer').addEventListener('click',()=>{if(running)return;running=true;$('timerMessage').textContent='Sesión en marcha. Concéntrate en una sola tarea.';timerId=setInterval(()=>{remaining--;renderTimer();if(remaining<=0){stopTimer();sessions++;minutes+=25;save('lu_sessions',sessions);save('lu_minutes',minutes);$('timerLabel').textContent='SESIÓN COMPLETADA';$('timerMessage').textContent='Buen trabajo. Tómate un descanso.';renderTimer();}},1000);});
$('pauseTimer').addEventListener('click',()=>{stopTimer();$('timerMessage').textContent='Sesión pausada. Reanuda cuando estés listo.';});
$('resetTimer').addEventListener('click',()=>{stopTimer();remaining=25*60;$('timerLabel').textContent='SESIÓN DE ENFOQUE';$('timerMessage').textContent='Deja el teléfono a un lado y empieza por una tarea.';renderTimer();});
if('serviceWorker' in navigator && location.protocol.startsWith('http')) navigator.serviceWorker.register('./sw.js').catch(()=>{});
renderTasks();renderGames();renderWorkout();renderTimer();
